const int ledMerah = 13;
const int ledKuning = 12;
const int ledHijau = 11;

void setup() {
  pinMode(ledMerah, OUTPUT);
  pinMode(ledKuning, OUTPUT);
  pinMode(ledHijau, OUTPUT);
}

void loop() {
  // Hijau
  digitalWrite(ledMerah, LOW);
  digitalWrite(ledKuning, LOW);
  digitalWrite(ledHijau, HIGH);
  delay(1000);

  // Kuning
  digitalWrite(ledMerah, LOW);
  digitalWrite(ledKuning, HIGH);
  digitalWrite(ledHijau, LOW);
  delay(1000);

  // Merah
  digitalWrite(ledMerah, HIGH);
  digitalWrite(ledKuning, LOW);
  digitalWrite(ledHijau, LOW);
  delay(1000);

  // Kuning lagi
  digitalWrite(ledMerah, LOW);
  digitalWrite(ledKuning, HIGH);
  digitalWrite(ledHijau, LOW);
  delay(1000);
}